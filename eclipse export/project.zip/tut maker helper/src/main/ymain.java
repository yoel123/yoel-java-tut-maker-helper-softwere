package main;

public class ymain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		yframe f = new yframe("tut making helper");
		f.yshow();
	}

}
