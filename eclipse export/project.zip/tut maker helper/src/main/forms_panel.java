package main;

import java.awt.LayoutManager;

import javax.swing.JPanel;

public class forms_panel extends JPanel {

	public forms_panel() {
		super();
		
	}

	public forms_panel(LayoutManager layout, boolean isDoubleBuffered) {
		super(layout, isDoubleBuffered);
		// TODO Auto-generated constructor stub
	}

	public forms_panel(LayoutManager layout) {
		super(layout);
		// TODO Auto-generated constructor stub
	}
	
	

}
